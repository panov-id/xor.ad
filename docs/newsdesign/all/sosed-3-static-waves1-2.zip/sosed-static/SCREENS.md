# sosed — экраны брифа (79)

| Волна | Экран | Что это | Файл |
|---|---|---|---|
| 1 | `feed` | Лента | w1_feed.svg |
| 1 | `feed-error` | Лента · ошибка | w1_feed-error.svg |
| 1 | `feed-hidden-return` | Лента · скрыто, вернуть (5 с) | w1_feed-hidden-return.svg |
| 1 | `feed-blocked` | Лента · автор заблокирован | w1_feed-blocked.svg |
| 2 | `feed-empty` | Лента пустая | w2_feed-empty.svg |
| 1 | `card` | Карточка | w1_card.svg |
| 1 | `card-liked` | Карточка · вы в деле | w1_card-liked.svg |
| 1 | `card-matched` | Карточка · оба в деле | w1_card-matched.svg |
| 1 | `card-details` | Карточка · детали | w1_card-details.svg |
| 1 | `card-more` | Карточка · меню «…» | w1_card-more.svg |
| 1 | `register-1` | Регистрация · шаг 1 | w1_register-1.svg |
| 1 | `register-2` | Регистрация · шаг 2 | w1_register-2.svg |
| 1 | `register-3` | Регистрация · шаг 3 | w1_register-3.svg |
| 2 | `splash` | Заставка | w2_splash.svg |
| 2 | `splash-lang` | Заставка · выбор языка | w2_splash-lang.svg |
| 2 | `lang` | Язык (из «Я») | w2_lang.svg |
| 2 | `loading` | Загрузка приложения | w2_loading.svg |
| 2 | `unlock` | Вход по ПИНу | w2_unlock.svg |
| 2 | `locked` | Блокировка по бездействию | w2_locked.svg |
| 2 | `away` | Вы отошли | w2_away.svg |
| 2 | `departure-start` | Перенос · отправление: начало | w2_departure-start.svg |
| 2 | `departure-code` | Перенос · одноразовый код | w2_departure-code.svg |
| 2 | `departure-claimed` | Перенос · сверка символов | w2_departure-claimed.svg |
| 2 | `departure-done` | Перенос · выполнен | w2_departure-done.svg |
| 2 | `arrival-code` | Перенос · прибытие: код | w2_arrival-code.svg |
| 2 | `arrival-check` | Перенос · прибытие: ждём подтверждения | w2_arrival-check.svg |
| 2 | `arrival-pin` | Перенос · прибытие: новый ПИН | w2_arrival-pin.svg |
| 3 | `chat` | Беседа | w3_chat.svg |
| 3 | `chat-game` | Беседа · игра | w3_chat-game.svg |
| 3 | `chat-more` | Беседа · меню «…» | w3_chat-more.svg |
| 3 | `chat-over` | Беседа · закончена | w3_chat-over.svg |
| 3 | `inbox` | Беседы | w3_inbox.svg |
| 3 | `tables` | Столы | w3_tables.svg |
| 3 | `new-table-1` | Новый стол · шаг 1: игра | w3_new-table-1.svg |
| 3 | `new-table-2` | Новый стол · шаг 2: вариант | w3_new-table-2.svg |
| 3 | `new-table-3` | Новый стол · шаг 3: предпросмотр | w3_new-table-3.svg |
| 3 | `table-dots` | Стол · Dots | w3_table-dots.svg |
| 3 | `table-checkers` | Стол · Checkers | w3_table-checkers.svg |
| 3 | `table-chess` | Стол · Chess | w3_table-chess.svg |
| 3 | `table-durak` | Стол · Durak | w3_table-durak.svg |
| 3 | `table-hangman` | Стол · Hangman | w3_table-hangman.svg |
| 3 | `table-backgammon` | Стол · Backgammon | w3_table-backgammon.svg |
| 3 | `table-dominoes` | Стол · Dominoes | w3_table-dominoes.svg |
| 3 | `table-chapayev` | Стол · Chapayev | w3_table-chapayev.svg |
| 3 | `table-reversi` | Стол · Reversi | w3_table-reversi.svg |
| 3 | `table-four` | Стол · Four in a row | w3_table-four.svg |
| 3 | `table-battleship` | Стол · Battleship | w3_table-battleship.svg |
| 3 | `table-poker` | Стол · Poker | w3_table-poker.svg |
| 3 | `composer` | Написать | w3_composer.svg |
| 3 | `likes` | Где я в деле | w3_likes.svg |
| 3 | `match` | Оба в деле · предложение поговорить | w3_match.svg |
| 3 | `match-waiting` | Оба в деле · ждём ответа | w3_match-waiting.svg |
| 4 | `me` | Я | w4_me.svg |
| 4 | `me-edit-name` | Я · имя и возраст | w4_me-edit-name.svg |
| 4 | `me-pin` | Я · сменить ПИН | w4_me-pin.svg |
| 4 | `me-reset` | Я · начать заново | w4_me-reset.svg |
| 4 | `step-away` | Я · отойти | w4_step-away.svg |
| 4 | `statements` | Ограничения | w4_statements.svg |
| 4 | `reissue-1` | Новый бумажный код · шаг 1 | w4_reissue-1.svg |
| 4 | `reissue-2` | Новый бумажный код · шаг 2 | w4_reissue-2.svg |
| 4 | `restore` | Восстановить по бумажному коду | w4_restore.svg |
| 4 | `hidden` | Скрытое | w4_hidden.svg |
| 4 | `blocked` | Заблокированные | w4_blocked.svg |
| 4 | `theme` | Тема | w4_theme.svg |
| 4 | `age-filter` | Фильтр по возрасту | w4_age-filter.svg |
| 4 | `legal` | Документы | w4_legal.svg |
| 4 | `cabinet-sign-in` | Кабинет · вход | w4_cabinet-sign-in.svg |
| 4 | `cabinet-sent` | Кабинет · письмо отправлено | w4_cabinet-sent.svg |
| 4 | `cabinet-venues` | Кабинет · заведения | w4_cabinet-venues.svg |
| 4 | `cabinet-new-offer` | Кабинет · новый оффер | w4_cabinet-new-offer.svg |
| 4 | `cabinet-offers` | Кабинет · офферы | w4_cabinet-offers.svg |
| 4 | `offer` | Переход по ссылке оффера | w4_offer.svg |
| 4 | `wizard-1` | Мастер · 1 фразы рядом | w4_wizard-1.svg |
| 4 | `wizard-2` | Мастер · 2 «я в деле» | w4_wizard-2.svg |
| 4 | `wizard-3` | Мастер · 3 столы и игры | w4_wizard-3.svg |
| 4 | `wizard-4` | Мастер · 4 ничего не уходит наружу | w4_wizard-4.svg |
| 4 | `wizard-5` | Мастер · 5 место | w4_wizard-5.svg |
| 4 | `place` | Место | w4_place.svg |
| 4 | `place-qr` | Место · QR | w4_place-qr.svg |
